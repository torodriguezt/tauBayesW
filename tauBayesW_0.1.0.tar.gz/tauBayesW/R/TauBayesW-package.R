#' tauBayesW: Bayesian Weighted Quantile Regression with EM and MCMC Algorithm
#'
#' The tauBayesW package provides Bayesian quantile regression methods for complex 
#' survey designs with two main functions:
#' 
#' \itemize{
#'   \item \code{bqr.svy()}: Single quantile estimation using MCMC methods
#'   \item \code{mo.bqr.svy()}: Multiple quantile estimation using EM algorithm
#' }
#'
#' @section Main functions:
#' \describe{
#'   \item{\code{\link{bqr.svy}}}{Fits Bayesian quantile regression for a single quantile using MCMC methods (ALD, Score, Approximate)}
#'   \item{\code{\link{mo.bqr.svy}}}{Fits Bayesian quantile regression for multiple quantiles using EM algorithm}
#'   \item{\code{\link{plot_quantile.bqr.svy}}}{Visualization function for fitted quantile regression models}
#'   \item{\code{\link{summary.bwqr_fit}}}{Summary method for single quantile fits}
#'   \item{\code{\link{summary.mo.bqr.svy}}}{Summary method for multiple quantile fits}
#' }
#'
#' @section MCMC Methods:
#' The package implements three MCMC methods for single quantile estimation:
#' \itemize{
#'   \item \strong{ALD (Asymmetric Laplace Distribution)}: Uses asymmetric Laplace likelihood
#'   \item \strong{Score}: Uses score-based approach
#'   \item \strong{Approximate}: Uses approximate methods for faster computation
#' }
#'
#' @section EM Algorithm:
#' The multiple output function uses an Expectation-Maximization algorithm 
#' based on the asymmetric Laplace distribution for efficient estimation 
#' of multiple quantiles simultaneously.
#'
#' @references 
#' Yu, K. and Moyeed, R. A. (2001). Bayesian quantile regression. 
#' \emph{Statistics & Probability Letters}, 54(4), 437-447.
#'
#' Kozumi, H. and Kobayashi, G. (2011). Gibbs sampling methods for Bayesian 
#' quantile regression. \emph{Journal of Statistical Computation and Simulation}, 
#' 81(11), 1565-1578.
#'
#' @author Marcus L. Nascimento, Kelly Cristina Mota Goncalves, 
#'         Johntan Cardona Jimenez, Tomas Rodriguez Taborda
#'
#' @keywords internal
#' @useDynLib tauBayesW, .registration = TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom grDevices adjustcolor
#' @importFrom graphics axis grid legend lines par points segments
"_PACKAGE"
